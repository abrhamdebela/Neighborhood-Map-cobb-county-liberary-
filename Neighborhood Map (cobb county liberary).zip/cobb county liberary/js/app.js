

var Locations = [
	{
		name: 'Gritters Library',
		lat: 34.02516,
		long: -84.524238
	},
	{
		name: 'Cobb County Law Library',
		lat: 33.9529817,
		long: -84.5485157
	},
	{
		name: 'Switzer Library',
		lat: 33.9500185,
		long: -84.5440069
	},
	{
		name: 'Kennesaw Branch Library',
		lat: 34.0243728,
		long:-84.6163919
	},
	{
		name: 'East Marietta Library',
		lat: 33.9501886,
		long: -84.49298309999999
	}
];

// its not strict mode so we do not need to Declaring global variables 
//var map;
//var clientID;
//var clientSecret;




var Location = function(info) {
	var self = this;
	self.name = info.name;
	self.lat = info.lat;
	self.long = info.long;
	self.URL = "";
	self.street = "";
	self.city = "";
	self.country = "" ;
	

	self.visible = ko.observable(true);
	
	

	var foursquareURL = 'https://api.foursquare.com/v2/venues/search?ll='+ this.lat + ',' + this.long + '&client_id=' + clientID + '&client_secret=' + clientSecret + '&v=20160118' + '&query=' + this.name;
//to extract the API of the address ,Street AND CITY from the foursuare url and using json 
	$.getJSON(foursquareURL).done(function(info) {
		var results = info.response.venues[0];
		self.URL = results.url;
		if (typeof self.URL === 'undefined'){
			self.URL = "http://www.cobbcat.org/libraries/";
		}
		self.street = results.location.formattedAddress[0];
     	self.city = results.location.formattedAddress[1];
		self.country = results.location.formattedAddress[2];
      
	}).fail(function() {
		alert("There was an error with the Foursquare API call. Please refresh the page and try again to load Foursquare data.");
	});
    
	self.contentString = '<div class="info-window-content"><div class="title"><b>' + info.name + "</b></div>" +
        '<div class="content"><a href="'  + self.URL + "</a></div>" +
        '<div class="content">'   + self.street + "</div>" +
        '<div class="content">'   + self.city + "</div>" 
		'<div class="content">'   + self.country + "</div>";
        

	self.infoWindow = new google.maps.InfoWindow({content: self.contentString});
       self.img = 'image/liberary.png';
	self.marker = new google.maps.Marker({
		    position: new google.maps.LatLng(info.lat, info.long),
			map: map,
			title: info.name,
			animation: google.maps.Animation.DROP,
			icon:this.img 
			 
	});
	

	self.showMarker = ko.computed(function() {
		if(self.visible() === true) {
			self.marker.setMap(map);
		} else {
			self.marker.setMap(null);
		}
		return true;
	}, self);
	
	
	
	self.marker.addListener('click', function(){
		self.contentString = '<div class="info-window-content"><div class="title"><b>' + info.name + "</b></div>" +
        '<div class="content"><a href="' + self.URL +'">' + self.URL + "</a></div>" +
        '<div class="content">' + self.street + "</div>" +
        '<div class="content">' + self.city + "</div>" +
		'<div class="content">' + self.country + "</div>";

        self.infoWindow.setContent(self.contentString);

		self.infoWindow.open(map, this);
		
		

		self.marker.setAnimation(google.maps.Animation.BOUNCE);
      	setTimeout(function() {
      		self.marker.setAnimation(null);
     	}, 2000);
	});

	self.bounce = function(place) {
		google.maps.event.trigger(self.marker, 'click');
	};
};

function AppViewModel() {
	var self = this;

	self.searchTerm = ko.observable("");

	self.locationList = ko.observableArray([]);

	map = new google.maps.Map(document.getElementById('map'), {
			zoom: 12,
			center: {lat: 33.9529817, lng: -84.5485157}
	});

	// Foursquare API settings
	clientID = "3PJR2HE2EVOKX4UFIAXJVYQMIQO0JS2JWDVN5XJYOJOVJFET";
	clientSecret = "QXWVAHIZGA3XCV4OGZGNFLWFGVL1LPZH051QXAUQEG5MR4HB";

	Locations.forEach(function(locationItem){
		self.locationList.push( new Location(locationItem));
	});
        //list out the liberary  name and search the liberary by inputing the name in the search box 
		
	self.filteredList = ko.computed( function() {
		var filter = self.searchTerm().toLowerCase();
		if (!filter) {
			self.locationList().forEach(function(locationItem){
				locationItem.visible(true);
			});
			return self.locationList();
		} else {
			return ko.utils.arrayFilter(self.locationList(), function(locationItem) {
				var string = locationItem.name.toLowerCase();
				var result = (string.search(filter) >= 0);
				locationItem.visible(result);
				return result;
			});
		}
	}, self);

	//self.mapElem = document.getElementById('map');
	
}
//immidiate calling the appviewmodel
function startApp() {
	ko.applyBindings(new AppViewModel());
}

function errorHandling() 
{
	alert("Google Maps has failed to load. Please check your internet connection and try again.");
}
